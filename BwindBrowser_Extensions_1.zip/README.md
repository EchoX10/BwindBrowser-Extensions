# B-wind Browser Extensions — pacote inicial

Este arquivo entrega a pasta **`Extensions`** pronta para ficar na raiz do repositório [`EchoX10/BwindBrowser-Extensions`](https://github.com/EchoX10/BwindBrowser-Extensions). Cada extensão está em uma pasta própria, possui um `manifest.json`, seus scripts e estilos completos e também um ZIP individual pronto para o B-wind Browser baixar.

## Estrutura do repositório

```text
BwindBrowser-Extensions/
└── Extensions/
    ├── catalog.json
    ├── ad-block/1.0.0/ad-block-1.0.0.zip
    ├── new-tab/1.0.0/new-tab-1.0.0.zip
    ├── night-theme/1.0.0/night-theme-1.0.0.zip
    ├── page-translator/1.0.0/page-translator-1.0.0.zip
    ├── reader-mode/1.0.0/reader-mode-1.0.0.zip
    └── site-tools/1.0.0/site-tools-1.0.0.zip
```

Os arquivos-fonte ficam ao lado de cada ZIP. Isso facilita revisar ou modificar o manifesto, o JavaScript, o CSS e, depois, gerar uma nova versão.

## Extensões incluídas

| Identificador | Extensão | Versão | Conteúdo |
|---|---|---:|---|
| `bwind.ad-block` | Bloqueador de Anúncios | 1.0.0 | Regras de domínios, ocultação de espaços publicitários e observador de conteúdo dinâmico. |
| `bwind.night-theme` | Tema Noturno de Páginas | 1.0.0 | CSS para fundo, texto, controles e mídias mais confortáveis à noite. |
| `bwind.reader-mode` | Modo Leitura | 1.0.0 | Botão de leitura, remoção de partes comuns de distração e ampliação de texto. |
| `bwind.page-translator` | Tradutor de Página | 1.0.0 | Botão que abre a página atual no Google Tradutor em português. |
| `bwind.new-tab` | Nova Aba B-wind | 1.0.0 | Página inicial local com pesquisa rápida. |
| `bwind.site-tools` | Ferramentas por Site | 1.0.0 | Painel flutuante para copiar título, endereço e texto selecionado. |

## Publicar no GitHub

Extraia este ZIP e envie a pasta **`Extensions`** para a raiz da branch `main` do seu repositório. Depois de publicar, o catálogo estará nesta URL:

```text
https://raw.githubusercontent.com/EchoX10/BwindBrowser-Extensions/main/Extensions/catalog.json
```

> Use a URL `raw.githubusercontent.com` no navegador. A URL normal `github.com` serve para ver os arquivos no site, mas não é a rota correta para baixar o ZIP diretamente.

## Criar uma atualização

Para atualizar uma extensão, nunca substitua silenciosamente o pacote antigo. Crie uma pasta de versão nova, por exemplo `Extensions/ad-block/1.1.0/`. Copie e altere os arquivos, mude o campo `version` do `manifest.json`, gere `ad-block-1.1.0.zip` e atualize a entrada correspondente em `catalog.json`.

O catálogo contém `latestVersion`, `packageUrl`, `manifestUrl` e `sha256`. O aplicativo deve baixar o catálogo na abertura, comparar a versão instalada com `latestVersion` e perguntar se a pessoa deseja atualizar. A instalação só deve continuar se o hash SHA-256 do ZIP baixado for igual ao valor do catálogo.

## Formato de manifesto

| Campo | Obrigatório | Finalidade |
|---|---:|---|
| `schemaVersion` | Sim | Versão do formato de extensão. |
| `id` | Sim | Identificador permanente, como `bwind.reader-mode`. |
| `name` | Sim | Nome exibido na lista do aplicativo. |
| `version` | Sim | Versão semântica do pacote. |
| `description` | Sim | Explica a função da extensão. |
| `type` | Sim | Tipo da extensão, como `content-script` ou `new-tab`. |
| `matches` | Sim | Páginas em que o conteúdo pode atuar. |
| `permissions` | Sim | Ações permitidas pelo navegador. |
| `entry` | Sim | Arquivos de script, estilo, regras ou página inicial. |
| `minBrowserVersion` | Sim | Versão mínima do B-wind Browser compatível. |

Extensões devem permanecer restritas ao conteúdo do WebView: CSS, JavaScript e regras declarativas. Elas não devem obter acesso a permissões Android, arquivos do aparelho, cookies privados ou interfaces nativas do aplicativo.
